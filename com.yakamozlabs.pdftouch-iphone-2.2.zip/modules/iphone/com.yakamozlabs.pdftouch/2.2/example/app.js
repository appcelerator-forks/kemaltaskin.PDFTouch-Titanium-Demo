var pdftouch = require('com.yakamozlabs.pdftouch');
var myapp = {};

myapp.createWindow = function() {
    var win = Ti.UI.createWindow({backgroundColor: 'white', navBarHidden: false, title: "PDFTouch SDK"});

    var data = [{title: "Open PDF ViewController"}];
    myapp.table = Ti.UI.createTableView({data: data, top: 0, left: 0, width: 320});
    myapp.table.addEventListener('click', function(e) {
      var f = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory, "Developers.pdf");
      if(!f.exists()) {
          var xhr = Titanium.Network.createHTTPClient({
              onload: function() {
                  Ti.API.info('PDF downloaded to applicationDataDirectory/Developers.pdf');
                  Ti.App.fireEvent('pdf_downloaded', {filePath:f.nativePath});
              },
              timeout: 10000
          });
          xhr.open('GET','http://www.enough.de/fileadmin/uploads/dev_guide_pdfs/Guide_11thEdition_WEB-1.pdf');
          xhr.file = Titanium.Filesystem.getFile(Titanium.Filesystem.applicationDataDirectory,'Developers.pdf');
          xhr.send();
      } else {
          Ti.App.fireEvent('pdf_downloaded', {filePath: f.nativePath});
      }
    });
    win.add(myapp.table);

    Ti.App.addEventListener('pdf_downloaded', function(e) {
        var document = pdftouch.createPDFDocument(e.filePath);
        if(document.isValidPDF()) {
            Ti.API.log("title: " + document.title());
            Ti.API.log("page count: " + document.pageCount());

            document.setPageCurlEnabled(true);
            document.setDocumentMode(1);
            document.setDismissButtonText("Close");
            document.display();
        }
    });

    var nav = Titanium.UI.iPhone.createNavigationGroup({window: win});
    var container = Ti.UI.createWindow();
    container.add(nav);

    return container;
};

myapp.window = myapp.createWindow();
myapp.window.open();
